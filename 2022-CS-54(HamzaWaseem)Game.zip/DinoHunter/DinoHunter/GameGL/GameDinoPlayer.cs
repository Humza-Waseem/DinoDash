﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DinoHunter.GameGL
{
    class GameDinoPlayer : GameObject
    {
        public GameDinoPlayer(Image image, GameCell startCell) : base(GameObjectType.PLAYER, image)
        {
            this.CurrentCell = startCell;
        }
        public GameCell move(GameDirection direction)
        {


            GameCell currentCell = this.CurrentCell;
            GameCell nextCell = currentCell.nextCell(direction);

            // Add the score to +1
            if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.REWARD)
            {
                Game.AddScore();

            }
            // Decrease the score to -10
            if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.ENEMY)
            {
                for (int i = 0; i <= 10; i++)
                {
                    Game.DecreaseScore();
                }

            }


            // add score +50
            if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.ENDSTAR)
            {
                for (int i = 0; i <= 50; i++)
                {
                    Game.AddScore();
                }
                

            }


            this.CurrentCell = nextCell;

            if (currentCell != nextCell)
            {
                currentCell.setGameObject(Game.getBlankGameObject());
            }
            


            return nextCell;
        }
    }
}
