﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DinoHunter.GameGL
{
    abstract class Enemy : GameObject
    {
        public GameDirection direction;
        public Enemy(char DisplayCharacter, GameObjectType type) : base(type, DisplayCharacter)
        {
            this.DisplayCharacter = DisplayCharacter;
            this.GameObjectType = type;
        }

        public Enemy(Image img, GameObjectType type) : base(type, img)
        {
            this.GameObjectType = type;
            this.Image = img;
        }


        public abstract GameCell MoveGhost(GameGrid grid);
    }
}
