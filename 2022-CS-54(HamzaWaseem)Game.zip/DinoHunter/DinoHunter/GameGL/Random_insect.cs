﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DinoHunter.GameGL
{
    class Random_insect : Enemy
    {
        Random r = new Random();
        public Random_insect(char DisplayCharacter, GameCell cell, GameObjectType type, GameDirection direction) : base(DisplayCharacter, type)
        {
            this.DisplayCharacter = DisplayCharacter;
            this.CurrentCell = cell;
            this.direction = direction;
            this.GameObjectType = type;
        }

        public Random_insect(Image img, GameCell cell, GameObjectType type, GameDirection direction) : base(img, type)
        {
            this.Image = img;
            this.CurrentCell = cell;
            this.direction = direction;
            this.GameObjectType = type;
        }


        public override GameCell MoveGhost(GameGrid gameGrid)
        {

            int value = r.Next(4);
            GameCell currentCell = this.CurrentCell;
            if (value == 0)
            {
                GameCell next = gameGrid.getCell(CurrentCell.X - 1, CurrentCell.Y);

                if (next.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                {
                    Game.SetFlag();
                }
                if (next.CurrentGameObject.GameObjectType != GameObjectType.WALL)
                {
                    if (next != null)
                    {
                        currentCell.setGameObject(Game.getCurrentObject(next));
                        CurrentCell = next;
                        return next;
                    }

                }
            }
            else if (value == 1)
            {
                GameCell next = gameGrid.getCell(CurrentCell.X + 1, CurrentCell.Y);
                if (next.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                {
                    Game.SetFlag();
                }
                if (next.CurrentGameObject.GameObjectType != GameObjectType.WALL)
                {
                    if (next != null)
                    {
                        currentCell.setGameObject(Game.getCurrentObject(next));
                        CurrentCell = next;
                        return next;
                    }
                }
            }

            else if (value == 2)
            {
                GameCell next = gameGrid.getCell(CurrentCell.X, CurrentCell.Y - 1);

                if (next.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                {
                    Game.SetFlag();
                }
                if (next.CurrentGameObject.GameObjectType != GameObjectType.WALL)
                {
                    if (next != null)
                    {
                        currentCell.setGameObject(Game.getCurrentObject(next));
                        CurrentCell = next;
                        return next;
                    }
                }
            }

            else if (value == 3)
            {
                GameCell next = gameGrid.getCell(CurrentCell.X, CurrentCell.Y + 1);
                if (next.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                {
                    Game.SetFlag();
                }
                if (next.CurrentGameObject.GameObjectType != GameObjectType.WALL)
                {
                    if (next != null)
                    {
                        currentCell.setGameObject(Game.getCurrentObject(next));
                        CurrentCell = next;
                        return next;
                    }
                }
            }

            return null;
        }
    }
}
