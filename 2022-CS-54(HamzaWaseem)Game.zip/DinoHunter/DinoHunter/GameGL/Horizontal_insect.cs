﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DinoHunter.GameGL
{
    class Horizontal_insect :Enemy
    {
        GameCell previous;
        public Horizontal_insect(char DisplayCharacter, GameCell cell, GameObjectType type, GameDirection direction) : base(DisplayCharacter, type)
        {
            this.DisplayCharacter = DisplayCharacter;
            this.CurrentCell = cell;
            this.direction = direction;
            this.GameObjectType = type;
        }

        public Horizontal_insect(Image img, GameCell cell, GameObjectType type, GameDirection direction) : base(img, type)
        {
            this.Image = img;
            this.CurrentCell = cell;
            this.direction = direction;
            this.GameObjectType = type;
        }

        public override GameCell MoveGhost(GameGrid grid)
        {
            GameCell currentCell = this.CurrentCell;

            if (direction == GameDirection.Left)
            {
                GameCell nextCell = grid.getCell(CurrentCell.X, CurrentCell.Y - 1);


                if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                {
                    Game.SetFlag();
                }
                if (nextCell.CurrentGameObject.GameObjectType != GameObjectType.WALL)
                {

                    if (nextCell != null)
                    {

                        currentCell.setGameObject(nextCell.CurrentGameObject);
                        CurrentCell = nextCell;
                        return nextCell;
                    }

                }


                else if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.WALL)
                {
                    direction = GameDirection.Right;
                }
            }

            if (direction == GameDirection.Right)
            {
                GameCell nextCell = grid.getCell(CurrentCell.X, CurrentCell.Y + 1);

                if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                {
                    Game.SetFlag();
                }
                if (nextCell.CurrentGameObject.GameObjectType != GameObjectType.WALL)
                {
                    if (nextCell != null)
                    {

                        currentCell.setGameObject(Game.getCurrentObject(nextCell));
                        CurrentCell = nextCell;
                        return nextCell;
                    }
                    if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.PLAYER)
                    {
                        Game.SetFlag();
                    }

                }

                else if (nextCell.CurrentGameObject.GameObjectType == GameObjectType.WALL)
                {

                    direction = GameDirection.Left;
                }

            }

            return null;


        }
    }
}
