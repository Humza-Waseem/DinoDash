﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DinoHunter
{
    public class Game
    {
        static int score = 0;
        static bool flag = true;
        public static GameObject getBlankGameObject()
        {
            GameObject blankGameObject = new GameObject(GameObjectType.NONE, DinoHunter.Properties.Resources.simplebox);
            return blankGameObject;
        }

        public static GameObject getCurrentObject(GameCell c)
        {

            GameObject Object = new GameObject(c.CurrentGameObject.GameObjectType, c.CurrentGameObject.Image);

            return Object;
        }

        public static void AddScore()
        {
            score++;

        }
        public static void DecreaseScore()
        {
            score--;

        }


        public static void SetFlag()
        {
            flag = false;
        }
        public static bool GetFlag()
        {
            return flag;
        }
        public static int ReturnScore()
        {
            return score;
        }
        public static Image getGameObjectImage(char displayCharacter)
        {
            Image img = DinoHunter.Properties.Resources.simplebox;
            if (displayCharacter == '|' || displayCharacter == '%')
            {
                img = DinoHunter.Properties.Resources.CroppedBoundary;
            }

            if (displayCharacter == '#')
            {
                img = DinoHunter.Properties.Resources.CroppedBoundary;
            }

            if (displayCharacter == '.')
            {
                img = DinoHunter.Properties.Resources.Burger;
            }
            if (displayCharacter == 'P' || displayCharacter == 'p')
            {
                img = DinoHunter.Properties.Resources.NewHunter;
            }
            if (displayCharacter == ' ')
            {
                img = DinoHunter.Properties.Resources.simplebox;
            }
            if(displayCharacter == 's' || displayCharacter == 'S')
            {
                img = DinoHunter.Properties.Resources.StarRemoved;
            }
            if (displayCharacter == 'B' || displayCharacter == 'b')
            {
                img = DinoHunter.Properties.Resources.Glowy;
            }

            return img;
        }
    }
}
